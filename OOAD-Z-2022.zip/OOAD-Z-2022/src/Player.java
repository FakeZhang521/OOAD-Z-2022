
class CDPlayer extends Player{

}

class RecordPlayer extends Player{

}

class MP3 extends Player{

}
