

class PaperScore extends Music{
}

class CD extends Music{
}

class Vinyl extends  Music{
}
