class Guitar extends Stringed{

}

class Bass extends Stringed{

}

class Mandolin extends Stringed{

}

