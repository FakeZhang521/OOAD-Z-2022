class Hat extends Clothing {
     int hatSize;
}

class Shirt extends Clothing{
    int shirtSize;
}

class Bandana extends Clothing{
}


