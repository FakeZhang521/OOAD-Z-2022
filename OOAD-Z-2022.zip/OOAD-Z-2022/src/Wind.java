class Flute extends Wind{
    String type;
}

class Harmonica extends Wind{
    String key;
}