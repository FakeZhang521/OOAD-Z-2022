class Stringed extends Instrument{
    String electric;
}

class Wind extends Instrument{

}