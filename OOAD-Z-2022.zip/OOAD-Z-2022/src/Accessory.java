class PracticeAmp extends Accessory {
    int wattage;
}

class Cable extends Accessory{
    int length;
}

class StringAcc extends Accessory{
    float type;
}



