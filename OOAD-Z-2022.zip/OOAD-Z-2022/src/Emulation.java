public class Emulation {
     public static void main(String[] args) throws IllegalAccessException {
          scheduler.startEmulation();
     }

}
